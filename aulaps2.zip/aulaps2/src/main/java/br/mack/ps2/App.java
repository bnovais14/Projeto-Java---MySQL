package br.mack.ps2;
import java.sql.*;
import java.util.Scanner;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main(String[] args) {

        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String db="ipbuta68_mackenzie";
            String url="jdbc:mysql://162.241.2.243:3306/"+db;
            String user="ipbuta68_mack";
            String psw="mackenzie";

            con=DriverManager.getConnection(url,user,psw);
            Scanner input = new Scanner(System.in);  // Create a Scanner object

         /*   System.out.println("Id: ");
            int id1 = input.nextInt();*/

            System.out.println("Digite seu nome: ");
            String nome1 = input.next();

            System.out.println("Digite o seu tia: ");
            int tia1 = input.nextInt();

            System.out.println("Digite o horario de entrada: ");
            String horaEntrada1 = input.next();

            System.out.println("Digite o horario de saida: ");
            String horaSaida1 = input.next();

            String inserir = "INSERT INTO frequencia VALUES(0,"+ tia1 +","+ "'"+ nome1 +"'"+","+ "'"+horaEntrada1 +"'"+","+"'"+ horaSaida1 +"'"+")";
            PreparedStatement stmInsert = con.prepareStatement(inserir);
             stmInsert.execute();
            System.out.println("Inserido");

            String sql = "SELECT * FROM ipbuta68_mackenzie.frequencia";
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();

            while (rs.next()){
                String nome = rs.getString("nome");
                String horaEntrada = rs.getString("horaEntrada");
                String horaSaida = rs.getString("horaSaida");
                int tia = rs.getInt("tia");
                int id = rs.getInt("id");

                System.out.println("Frequência #"+id+"-"+" Tia: "+tia+"-"+" Nome: "+nome+"-"+" Entrada : "+horaEntrada+"-"+" Saida: "+horaSaida);
            }
            rs.close();
            con.close();

        }
        catch(Exception e){
            e.printStackTrace();
        }

    }
}
