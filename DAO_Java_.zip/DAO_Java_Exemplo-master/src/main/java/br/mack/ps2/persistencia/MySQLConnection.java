package br.mack.ps2.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySQLConnection {
    String db="ipbuta68_mackenzie";
    String url = "jdbc:mysql://162.241.2.243:3306/"+db;
    String usuario = "ipbuta68_mack";
    String senha = "mackenzie";

    public Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, usuario, senha);
        } catch (final Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
