package br.mack.ps2;
import java.math.BigDecimal;
import java.sql.*;
import java.util.Scanner;


public class App
{
    public static void main(String[] args) {

        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String db="ipbuta68_mackenzie";
            String url="jdbc:mysql://162.241.2.243:3306/"+db;
            String user="ipbuta68_mack";
            String psw="mackenzie";

            con=DriverManager.getConnection(url,user,psw);
            Scanner input = new Scanner(System.in);  // Create a Scanner object

            System.out.println("Digite numero da sua conta: ");
            int numConta = input.nextInt();

            String delete = "DELETE FROM ipbuta68_mackenzie.contas where nro_conta = "+ numConta;
            PreparedStatement stmDelete = con.prepareStatement(delete);
            stmDelete.execute();
            System.out.println("Conta deletada com sucesso");

            String sql = "SELECT * FROM ipbuta68_mackenzie.contas";
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            int cont = 0;
            System.out.println("Contas disponíveis:");
            while (rs.next()){

                cont++;
                System.out.println("Registro " + cont);
                long nroConta = rs.getLong("nro_conta");
                BigDecimal saldos = rs.getBigDecimal("saldo");

                System.out.println("Numero da conta:  " + nroConta + " ---- Saldo: R$ " + saldos);
            }
            rs.close();


        }
        catch (final ClassNotFoundException ex)
        {
            System.out.println("Falha na carga do Driver JDBC!");
        }
        catch (final SQLException ex)
        {
            System.out.println("Falha de conexão com a base de dados!");
        }
        finally
        {
            try {
                con.close();
            }
            catch (final Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }

}

